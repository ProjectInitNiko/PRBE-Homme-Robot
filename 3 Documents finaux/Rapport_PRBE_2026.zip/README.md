# Rapport PRBE — projet LaTeX

Rapport du projet *Simulation du mouvement humain et interaction homme-robot dans
RoboDK* (sujet #47, ligne ALIX, ISAE-SUPMÉCA). Gabarit repris du template école.

## Structure

```
rapport/
├── main.tex              # préambule (template école) + page de garde + structure
├── references.bib        # bibliographie
├── Page_Garde/           # fond ISAE (watermark) + logo
├── Images/               # logos
├── figures/              # captures RoboDK + schémas cinématiques
└── sections/
    ├── 00-contexte.tex            # [Alex/Luc] contexte & objectifs
    ├── 01-cahier-des-charges.tex  # [Alex/Luc] cahier des charges (à condenser)
    ├── 02-etat-de-l-art.tex       # [Alex/Luc] état de l'art
    ├── 03-modele-conceptuel.tex   # [NIKO] cinématique + démarche + arborescence repères
    ├── 04-developpement.tex       # [NIKO] animation, marches, tâche bras
    ├── 05-tests-resultats.tex     # [NIKO] problèmes/corrections, résolu vs perspective
    └── 06-conclusion.tex          # [NIKO] objectifs + perspectives
```

## Compiler

### Overleaf (le plus simple)
Compresser le dossier `rapport/` en `.zip`, *New Project → Upload Project*,
fichier principal `main.tex`, compilateur **pdfLaTeX**.

### Local (MiKTeX / TeX Live)
```
pdflatex main
bibtex main
pdflatex main
pdflatex main
```
(2 passes après bibtex pour résoudre la table des matières et les `\cref`.)

## Répartition

- **Niko** : sections 4 (modèle conceptuel — partie RoboDK), 5, 6, 7.
- **Alex / Luc** : contexte, cahier des charges, état de l'art, cinématique formelle.

## À finaliser

- Remplacer les figures `bras_seq*` par de vraies captures de `Tache_Bras.py` (table + cube).
- Raccorder les sections 1–3 (placeholders) avec les contenus d'Alex & Luc.
- Vérifier les amplitudes du tableau des 22 DDL et compléter les DOI dans `references.bib`.
